package com.emailapi;

public class AttachmentDto {
	
	private long aid;
	private String alink;
	
	
	public AttachmentDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getAid() {
		return aid;
	}
	public void setAid(long aid) {
		this.aid = aid;
	}
	public String getAlink() {
		return alink;
	}
	public void setAlink(String alink) {
		this.alink = alink;
	}
	
	

}
